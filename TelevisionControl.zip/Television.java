package lab4;

public class Television {
	//private String brand;
	private String MANUFACTURER;
	private int SCREEN_SIZE;
	private boolean powerOn = false;
	private int channel = 2;
	private int volume = 20;
	/**
	 *  this constructor sets the values from TelevisionDemo to the variables in this class
	 * @param string
	 * @param i
	 */
	public Television(String string, int i) {
		// TODO Auto-generated constructor stub
		MANUFACTURER = string;
		SCREEN_SIZE = i;
	}
	/**
	 * this method sets the parameter to the private variable station
	 * @param station
	 */
	public void setChannel(int station) {
		channel = station;	
	}
	/**
	 * this method sets the power to true if the power is on
	 */
	public void power() {
	powerOn = true;
	if (powerOn != true)
		powerOn = !powerOn;
	
	}
	/**
	 * method increases set volume by 1
	 */
	public void increaseVolume() {
		volume++;
	}
	/**
	 * method decreases set volume by 1
	 */
	public void decreaseVolume() {
		volume--;
	}
	/**
	 * this method returns channel so that it can be called and return a value
	 * @return
	 */
	public int getChannel() {
		return channel;
	}
	/**
	 * this method returns the volume to where it is called
	 * @return
	 */
	public int getVolume() {
		return volume;
	}
	
	/**
	 * this method returns the name of the manufacturer where it is called
	 * @return
	 */
	public String getManufacturer() {
		return MANUFACTURER;
	}
	/**
	 * this method returns the size of the screen to where it is called
	 * @return
	 */
	public int getScreenSize() {
		return SCREEN_SIZE;
	}

}
